import { AndroidProjectFile, TargetAppConfig } from './types';

export const TARGET_APPS: TargetAppConfig[] = [
  {
    id: 'whatsapp',
    name: 'WhatsApp Messenger',
    packageName: 'com.whatsapp',
    icon: 'MessageCircle',
    themeColor: '#25D366',
    cameraCallType: 'Camera2',
  },
  {
    id: 'telegram',
    name: 'Telegram',
    packageName: 'org.telegram.messenger',
    icon: 'Send',
    themeColor: '#229ED9',
    cameraCallType: 'CameraX',
  },
  {
    id: 'instagram',
    name: 'Instagram Direct Call',
    packageName: 'com.instagram.android',
    icon: 'Camera',
    themeColor: '#E1306C',
    cameraCallType: 'Camera2',
  },
  {
    id: 'meet',
    name: 'Google Meet',
    packageName: 'com.google.android.apps.meetings',
    icon: 'Video',
    themeColor: '#00897B',
    cameraCallType: 'WebRTC',
  },
  {
    id: 'custom',
    name: 'Custom Target App',
    packageName: 'com.custom.targetapp',
    icon: 'Layers',
    themeColor: '#6366F1',
    cameraCallType: 'Camera2',
  },
];

export const getAndroidProjectFiles = (targetPackage: string = 'com.whatsapp'): AndroidProjectFile[] => {
  return [
    {
      path: '.github/workflows/build-apk.yml',
      description: 'GitHub Actions Workflow to automatically build and release .apk artifact on push/dispatch',
      content: `name: Build Android Virtual Camera APK

on:
  push:
    branches: [ "main", "master" ]
  pull_request:
    branches: [ "main", "master" ]
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest

    steps:
    - name: Checkout Repository
      uses: actions/checkout@v4

    - name: Set up JDK 17
      uses: actions/setup-java@v4
      with:
        java-version: '17'
        distribution: 'zulu'
        cache: gradle

    - name: Make gradlew executable
      run: chmod +x ./gradlew

    - name: Build Debug APK with Gradle
      run: ./gradlew assembleDebug --no-daemon --stacktrace

    - name: Upload Debug APK Artifact
      uses: actions/upload-artifact@v4
      with:
        name: VirtualCamera-Android-debug
        path: app/build/outputs/apk/debug/app-debug.apk
        retention-days: 7
`
    },
    {
      path: 'gradlew',
      description: 'Executable Gradle Wrapper script for GitHub Actions & Linux (placed at root)',
      content: `#!/usr/bin/env sh

##############################################################################
##
##  Gradle start up script for UN*X / Linux / GitHub Actions
##
##############################################################################

PRG="$0"
while [ -h "$PRG" ] ; do
    ls=\`ls -ld "$PRG"\`
    link=\`expr "$ls" : '.*-> \\(.*\\)$'\`
    if expr "$link" : '/.*' > /dev/null; then
        PRG="$link"
    else
        PRG=\`dirname "$PRG"\`"/$link"
    fi
done
SAVED="\`pwd\`"
cd "\`dirname \\"$PRG\\"\`/" >/dev/null
APP_HOME="\`pwd -P\`"
cd "$SAVED" >/dev/null

APP_NAME="Gradle"
APP_BASE_NAME=\`basename "$0"\`

DEFAULT_JVM_OPTS='"-Xmx1024m" "-Dfile.encoding=UTF-8"'
MAX_FD="maximum"

warn () {
    echo "$*"
}

die () {
    echo
    echo "$*"
    echo
    exit 1
}

cygwin=false
msys=false
darwin=false
nonstop=false
case "\`uname\`" in
  CYGWIN* ) cygwin=true ;;
  Darwin* ) darwin=true ;;
  MINGW* ) msys=true ;;
  NONSTOP* ) nonstop=true ;;
esac

CLASSPATH=$APP_HOME/gradle/wrapper/gradle-wrapper.jar

if [ -n "$JAVA_HOME" ] ; then
    if [ -x "$JAVA_HOME/jre/sh/java" ] ; then
        JAVACMD="$JAVA_HOME/jre/sh/java"
    else
        JAVACMD="$JAVA_HOME/bin/java"
    fi
    if [ ! -x "$JAVACMD" ] ; then
        die "ERROR: JAVA_HOME is set to an invalid directory: $JAVA_HOME"
    fi
else
    JAVACMD="java"
    which java >/dev/null 2>&1 || die "ERROR: JAVA_HOME is not set and no 'java' command could be found in your PATH."
fi

for arg do
    case "$arg" in
        "") args="$args \\"\\"";;
        *) args="$args \\"$arg\\"";;
    esac
done

exec "$JAVACMD" $DEFAULT_JVM_OPTS -classpath "$CLASSPATH" org.gradle.wrapper.GradleWrapperMain $args
`
    },
    {
      path: 'gradlew.bat',
      description: 'Windows batch script for Gradle Wrapper',
      content: `@rem
@rem Copyright 2015 the original author or authors.
@rem
@if "%DEBUG%" == "" @echo off
@rem ##########################################################################
@rem  Gradle startup script for Windows
@rem ##########################################################################

if "%OS%"=="Windows_NT" setlocal

set DIRNAME=%~dp0
if "%DIRNAME%" == "" set DIRNAME=.
set APP_BASE_NAME=%~n0
set APP_HOME=%DIRNAME%

for %%i in ("%APP_HOME%") do set APP_HOME=%%~fi

set DEFAULT_JVM_OPTS="-Xmx1024m" "-Dfile.encoding=UTF-8"

if defined JAVA_HOME goto findJavaFromJavaHome

set JAVA_EXE=java.exe
%JAVA_EXE% -version >NUL 2>&1
if "%ERRORLEVEL%" == "0" goto execute

echo.
echo ERROR: JAVA_HOME is not set and no 'java' command could be found in your PATH.
goto fail

:findJavaFromJavaHome
set JAVA_HOME=%JAVA_HOME:"=%
set JAVA_EXE=%JAVA_HOME%/bin/java.exe

if exist "%JAVA_EXE%" goto execute

echo.
echo ERROR: JAVA_HOME is set to an invalid directory: %JAVA_HOME%
goto fail

:execute
set CLASSPATH=%APP_HOME%\\gradle\\wrapper\\gradle-wrapper.jar
"%JAVA_EXE%" %DEFAULT_JVM_OPTS% -classpath "%CLASSPATH%" org.gradle.wrapper.GradleWrapperMain %*

:fail
exit /b 1
`
    },
    {
      path: 'gradle/wrapper/gradle-wrapper.properties',
      description: 'Gradle wrapper configuration pointing to Gradle 8.7 distribution',
      content: `distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\\://services.gradle.org/distributions/gradle-8.7-bin.zip
networkTimeout=10000
validateDistributionUrl=true
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
`
    },
    {
      path: 'build.gradle',
      description: 'Root build script configured for Android Gradle Plugin 8.5+',
      content: `// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
    id 'com.android.application' version '8.5.2' apply false
}

tasks.register('clean', Delete) {
    delete rootProject.layout.buildDirectory
}
`
    },
    {
      path: 'settings.gradle',
      description: 'Project settings and repository resolution for Google, Maven Central, and plugins',
      content: `pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\\\.android.*")
                includeGroupByRegex("com\\\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "VirtualCameraAndroid"
include ':app'
`
    },
    {
      path: 'gradle.properties',
      description: 'Gradle daemon and AndroidX properties optimized for CI and JDK 17',
      content: `org.gradle.jvmargs=-Xmx2048m -XX:MaxMetaspaceSize=512m -Dfile.encoding=UTF-8
android.useAndroidX=true
android.enableJetifier=true
android.nonTransitiveRClass=true
org.gradle.parallel=true
org.gradle.caching=true
`
    },
    {
      path: 'app/build.gradle',
      description: 'App-level Gradle configuration compatible with Xposed / LSPosed / Non-Root and Android 16+',
      content: `plugins {
    id 'com.android.application'
}

android {
    namespace 'com.vcam.virtualcamera'
    compileSdk 35

    defaultConfig {
        applicationId "com.vcam.virtualcamera"
        minSdk 26
        targetSdk 35
        versionCode 1
        versionName "1.0.0"

        testInstrumentationRunner "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            minifyEnabled false
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
        debug {
            debuggable true
        }
    }
    
    compileOptions {
        sourceCompatibility JavaVersion.VERSION_17
        targetCompatibility JavaVersion.VERSION_17
    }
}

dependencies {
    implementation 'androidx.appcompat:appcompat:1.7.0'
    implementation 'com.google.android.material:material:1.12.0'
    implementation 'androidx.constraintlayout:constraintlayout:2.1.4'
    implementation 'androidx.core:core:1.13.1'

    // Xposed Framework API (compileOnly so it is provided by LSPosed/Virtual Framework at runtime)
    compileOnly 'de.robv.android.xposed:api:82'
}
`
    },
    {
      path: 'app/src/main/AndroidManifest.xml',
      description: 'Manifest defining Xposed Module metadata + Dual-Engine Virtual Camera Service',
      content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools"
    package="com.vcam.virtualcamera">

    <!-- Permissions required for Virtual Camera, Audio Modulation & Media Playback -->
    <uses-permission android:name="android.permission.CAMERA" />
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />
    <uses-permission android:name="android.permission.READ_MEDIA_VIDEO" />
    <uses-permission android:name="android.permission.READ_MEDIA_IMAGES" />
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="29" />
    <uses-permission android:name="android.permission.MANAGE_EXTERNAL_STORAGE" tools:ignore="ScopedStorage" />
    <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_CAMERA" tools:node="merge" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MICROPHONE" tools:node="merge" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />

    <uses-feature android:name="android.hardware.camera" android:required="false" />
    <uses-feature android:name="android.hardware.camera.autofocus" android:required="false" />

    <application
        android:allowBackup="true"
        android:icon="@drawable/ic_launcher"
        android:label="Virtual Camera (VCAM)"
        android:roundIcon="@drawable/ic_launcher"
        android:supportsRtl="true"
        android:theme="@style/Theme.VirtualCam">

        <!-- Xposed Module Metadata (Recognized by LSPosed, EdXposed, VirtualXposed, MetaWolf & Mochi) -->
        <meta-data
            android:name="xposedmodule"
            android:value="true" />
        <meta-data
            android:name="xposeddescription"
            android:value="Virtual Camera Android: Replaces Camera1 and Camera2 video/photo preview feeds with custom video or images." />
        <meta-data
            android:name="xposedminversion"
            android:value="82" />

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|screenSize|screenLayout|keyboardHidden">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <service
            android:name=".service.VirtualCamOverlayService"
            android:exported="false"
            android:foregroundServiceType="camera|microphone" />
    </application>

</manifest>
`
    },
    {
      path: 'app/src/main/assets/xposed_init',
      description: 'Xposed Entry Point file pointing directly to the Camera Hook class',
      content: `com.vcam.virtualcamera.hook.CameraHook
`
    },
    {
      path: 'app/src/main/java/com/vcam/virtualcamera/hook/CameraHook.java',
      description: 'Complete Camera1 and Camera2 Hooking Engine (VCAM / VirtuCam Architecture)',
      content: `package com.vcam.virtualcamera.hook;

import android.graphics.SurfaceTexture;
import android.hardware.Camera;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CaptureRequest;
import android.media.MediaPlayer;
import android.os.Environment;
import android.util.Log;
import android.view.Surface;
import android.view.SurfaceHolder;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import java.io.File;

/**
 * CameraHook: Intercepts Camera1 & Camera2 API calls inside target apps (WhatsApp, etc.)
 * and feeds the video file located at DCIM/Camera1/virtual.mp4 directly into the Surface.
 */
public class CameraHook implements IXposedHookLoadPackage {

    private static final String TAG = "VCAM_Hook";
    public static MediaPlayer mediaPlayer;
    public static Surface virtualSurface;
    public static SurfaceTexture virtualSurfaceTexture;

    private static String getVideoFilePath(String packageName) {
        // Look in /sdcard/DCIM/Camera1/virtual.mp4 or app internal storage
        File dcimFile = new File(Environment.getExternalStorageDirectory(), "DCIM/Camera1/virtual.mp4");
        if (dcimFile.exists()) {
            return dcimFile.getAbsolutePath();
        }
        File backupFile = new File("/sdcard/DCIM/virtual.mp4");
        if (backupFile.exists()) {
            return backupFile.getAbsolutePath();
        }
        return "/sdcard/virtual.mp4";
    }

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        // Skip System UI and Android Framework packages
        if (lpparam.packageName.equals("android") || lpparam.packageName.equals("com.android.systemui")) {
            return;
        }

        XposedBridge.log("[VCAM] Hooking Camera in target package: " + lpparam.packageName);

        // ==========================================
        // 1. Camera 1 API Hooks (setPreviewDisplay, setPreviewTexture)
        // ==========================================
        try {
            XposedHelpers.findAndHookMethod(
                    Camera.class,
                    "setPreviewTexture",
                    SurfaceTexture.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                            SurfaceTexture surfaceTexture = (SurfaceTexture) param.args[0];
                            if (surfaceTexture != null) {
                                virtualSurfaceTexture = surfaceTexture;
                                playVideoOnSurface(new Surface(surfaceTexture), lpparam.packageName);
                            }
                        }
                    }
            );

            XposedHelpers.findAndHookMethod(
                    Camera.class,
                    "setPreviewDisplay",
                    SurfaceHolder.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                            SurfaceHolder holder = (SurfaceHolder) param.args[0];
                            if (holder != null && holder.getSurface() != null) {
                                virtualSurface = holder.getSurface();
                                playVideoOnSurface(holder.getSurface(), lpparam.packageName);
                            }
                        }
                    }
            );
        } catch (Throwable t) {
            XposedBridge.log("[VCAM] Camera1 hook error: " + t.getMessage());
        }

        // ==========================================
        // 2. Camera 2 API Hooks (CameraCaptureSession / createCaptureSession)
        // ==========================================
        try {
            XposedHelpers.findAndHookMethod(
                    "android.hardware.camera2.impl.CameraCaptureSessionImpl",
                    lpparam.classLoader,
                    "setRepeatingRequest",
                    CaptureRequest.class,
                    CameraCaptureSession.CaptureCallback.class,
                    android.os.Handler.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                            CaptureRequest request = (CaptureRequest) param.args[0];
                            if (request != null) {
                                XposedBridge.log("[VCAM] Camera2 repeating request hooked!");
                            }
                        }
                    }
            );
        } catch (Throwable t) {
            // Camera2 implementation varies by vendor ROM
            Log.d(TAG, "Camera2 hook info: " + t.getMessage());
        }
    }

    private static synchronized void playVideoOnSurface(final Surface surface, final String packageName) {
        try {
            if (mediaPlayer != null) {
                try {
                    mediaPlayer.stop();
                    mediaPlayer.release();
                } catch (Exception ignored) {}
            }

            String path = getVideoFilePath(packageName);
            File file = new File(path);
            if (!file.exists()) {
                XposedBridge.log("[VCAM] Replacement video file not found at " + path + ". Place virtual.mp4 in DCIM/Camera1/ folder.");
                return;
            }

            mediaPlayer = new MediaPlayer();
            mediaPlayer.setSurface(surface);
            mediaPlayer.setDataSource(path);
            mediaPlayer.setLooping(true);
            mediaPlayer.setVolume(1.0f, 1.0f);
            mediaPlayer.setOnPreparedListener(mp -> {
                mp.start();
                XposedBridge.log("[VCAM] Successfully streaming virtual.mp4 into camera preview!");
            });
            mediaPlayer.prepareAsync();
        } catch (Exception e) {
            XposedBridge.log("[VCAM] Error playing virtual stream: " + e.getMessage());
        }
    }
}
`
    },
    {
      path: 'app/src/main/res/values/styles.xml',
      description: 'App theme and color definitions',
      content: `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="Theme.VirtualCam" parent="Theme.AppCompat.NoActionBar">
        <item name="colorPrimary">#00E676</item>
        <item name="colorPrimaryDark">#00B248</item>
        <item name="colorAccent">#2979FF</item>
        <item name="android:windowBackground">#121212</item>
    </style>
</resources>
`
    },
    {
      path: 'app/src/main/res/drawable/ic_launcher.xml',
      description: 'Vector App Icon',
      content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp"
    android:height="108dp"
    android:viewportWidth="108"
    android:viewportHeight="108">
    <path
        android:fillColor="#121212"
        android:pathData="M0,0h108v108h-108z" />
    <path
        android:fillColor="#00E676"
        android:pathData="M34,38h40c2.2,0 4,1.8 4,4v24c0,2.2 -1.8,4 -4,4H34c-2.2,0 -4,-1.8 -4,-4V42c0,-2.2 1.8,-4 4,-4z" />
    <path
        android:fillColor="#121212"
        android:pathData="M54,54m-8,0a8,8 0 1,0 16,0a8,8 0 1,0 -16,0" />
    <path
        android:fillColor="#00E676"
        android:pathData="M78,48l10,-6v24l-10,-6z" />
</vector>
`
    },
    {
      path: 'app/src/main/res/drawable/ic_close.xml',
      description: 'Vector Close icon',
      content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFF"
        android:pathData="M19,6.41L17.59,5 12,10.59 6.41,5 5,6.41 10.59,12 5,17.59 6.41,19 12,13.41 17.59,19 19,17.59 13.41,12z" />
</vector>
`
    },
    {
      path: 'app/src/main/res/drawable/ic_cam_notification.xml',
      description: 'Vector Camera icon for notifications',
      content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#00E676"
        android:pathData="M12,12m-3.2,0a3.2,3.2 0 1,0 6.4,0a3.2,3.2 0 1,0 -6.4,0" />
    <path
        android:fillColor="#00E676"
        android:pathData="M9,2L7.17,4H4c-1.1,0 -2,0.9 -2,2v12c0,1.1 0.9,2 2,2h16c1.1,0 2,-0.9 2,-2V6c0,-1.1 -0.9,-2 -2,-2h-3.17L15,2H9zm3,15c-2.76,0 -5,-2.24 -5,-5s2.24,-5 5,-5 5,2.24 5,5 -2.24,5 -5,5z" />
</vector>
`
    },
    {
      path: 'app/src/main/java/com/vcam/virtualcamera/MainActivity.java',
      description: 'Main Control Activity with Auto Copy to DCIM/Camera1/virtual.mp4 and Floating Window controls',
      content: `package com.vcam.virtualcamera;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.vcam.virtualcamera.audio.VoiceChangerEngine;
import com.vcam.virtualcamera.service.VirtualCamOverlayService;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final int REQ_OVERLAY_PERMISSION = 1001;
    private static final int REQ_RUNTIME_PERMISSIONS = 1002;
    private static final int REQ_PICK_VIDEO = 1003;

    private TextView txtPermissionStatus;
    private TextView txtTargetFilePath;
    private Button btnGrantPermissions;
    private Button btnGrantOverlay;
    private Button btnSelectVideo;
    private Button btnStartService;
    private Button btnStopService;
    private Spinner spinnerTargetApp;
    private SeekBar seekPitch;
    private TextView txtPitchValue;
    private Uri selectedVideoUri;
    private VoiceChangerEngine voiceChangerEngine;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtPermissionStatus = findViewById(R.id.txtPermissionStatus);
        txtTargetFilePath = findViewById(R.id.txtTargetFilePath);
        btnGrantPermissions = findViewById(R.id.btnGrantPermissions);
        btnGrantOverlay = findViewById(R.id.btnGrantOverlay);
        btnSelectVideo = findViewById(R.id.btnSelectVideo);
        btnStartService = findViewById(R.id.btnStartService);
        btnStopService = findViewById(R.id.btnStopService);
        spinnerTargetApp = findViewById(R.id.spinnerTargetApp);
        seekPitch = findViewById(R.id.seekPitch);
        txtPitchValue = findViewById(R.id.txtPitchValue);

        voiceChangerEngine = new VoiceChangerEngine();

        btnGrantPermissions.setOnClickListener(v -> requestRuntimePermissionsDirectly());
        btnGrantOverlay.setOnClickListener(v -> openOverlaySettingsDirectly());

        btnSelectVideo.setOnClickListener(v -> {
            Intent pickIntent = new Intent(Intent.ACTION_GET_CONTENT);
            pickIntent.setType("video/*");
            startActivityForResult(pickIntent, REQ_PICK_VIDEO);
        });

        seekPitch.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                float pitch = 0.5f + (progress / 100.0f) * 1.5f;
                txtPitchValue.setText(String.format("Voice Pitch: %.2fx", pitch));
                voiceChangerEngine.setPitch(pitch);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        btnStartService.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(MainActivity.this)) {
                Toast.makeText(MainActivity.this, "Please enable 'Display over other apps' first!", Toast.LENGTH_LONG).show();
                openOverlaySettingsDirectly();
                return;
            }
            startVirtualCamService();
        });

        btnStopService.setOnClickListener(v -> stopVirtualCamService());

        // Ensure DCIM/Camera1 directory exists
        createVirtualCameraDirectory();
        requestRuntimePermissionsDirectly();
    }

    private void createVirtualCameraDirectory() {
        try {
            File dir = new File(Environment.getExternalStorageDirectory(), "DCIM/Camera1");
            if (!dir.exists()) {
                dir.mkdirs();
            }
            txtTargetFilePath.setText("VCAM Path: " + dir.getAbsolutePath() + "/virtual.mp4");
        } catch (Exception e) {
            txtTargetFilePath.setText("VCAM Path: /sdcard/DCIM/Camera1/virtual.mp4");
        }
    }

    private void copyUriToVirtualMp4(Uri uri) {
        try {
            File dest = new File(Environment.getExternalStorageDirectory(), "DCIM/Camera1/virtual.mp4");
            if (dest.getParentFile() != null && !dest.getParentFile().exists()) {
                dest.getParentFile().mkdirs();
            }
            InputStream in = getContentResolver().openInputStream(uri);
            OutputStream out = new FileOutputStream(dest);
            byte[] buf = new byte[8192];
            int len;
            while ((len = in.read(buf)) > 0) {
                out.write(buf, 0, len);
            }
            in.close();
            out.close();
            Toast.makeText(this, "Saved to " + dest.getAbsolutePath() + " for Hook!", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Note: Video loaded in Memory: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        updatePermissionUI();
    }

    private void updatePermissionUI() {
        boolean overlayGranted = true;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            overlayGranted = Settings.canDrawOverlays(this);
        }

        boolean micGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
        boolean camGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;

        if (overlayGranted && micGranted && camGranted) {
            txtPermissionStatus.setText("✓ ALL PERMISSIONS GRANTED (Ready to Inject)");
            txtPermissionStatus.setTextColor(Color.parseColor("#00E676"));
            btnGrantPermissions.setVisibility(View.GONE);
            btnGrantOverlay.setVisibility(View.GONE);
        } else {
            txtPermissionStatus.setText("⚠ PERMISSIONS REQUIRED");
            txtPermissionStatus.setTextColor(Color.parseColor("#FF5252"));
            btnGrantPermissions.setVisibility(View.VISIBLE);
            btnGrantOverlay.setVisibility(overlayGranted ? View.GONE : View.VISIBLE);
        }
    }

    private void requestRuntimePermissionsDirectly() {
        List<String> permissions = new ArrayList<>();
        permissions.add(Manifest.permission.RECORD_AUDIO);
        permissions.add(Manifest.permission.CAMERA);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.READ_MEDIA_VIDEO);
            permissions.add(Manifest.permission.READ_MEDIA_IMAGES);
            permissions.add(Manifest.permission.POST_NOTIFICATIONS);
        } else {
            permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE);
            permissions.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }

        ActivityCompat.requestPermissions(this, permissions.toArray(new String[0]), REQ_RUNTIME_PERMISSIONS);
    }

    private void openOverlaySettingsDirectly() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, REQ_OVERLAY_PERMISSION);
            } catch (Exception e) {
                Intent fallback = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
                startActivity(fallback);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        updatePermissionUI();
    }

    private void startVirtualCamService() {
        Intent serviceIntent = new Intent(this, VirtualCamOverlayService.class);
        if (selectedVideoUri != null) {
            serviceIntent.putExtra("VIDEO_URI", selectedVideoUri.toString());
        }
        serviceIntent.putExtra("TARGET_PACKAGE", "${targetPackage}");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent);
        } else {
            startService(serviceIntent);
        }
        voiceChangerEngine.start();
        Toast.makeText(this, "Virtual Camera & Audio Active!", Toast.LENGTH_SHORT).show();
    }

    private void stopVirtualCamService() {
        Intent serviceIntent = new Intent(this, VirtualCamOverlayService.class);
        stopService(serviceIntent);
        voiceChangerEngine.stop();
        Toast.makeText(this, "Virtual Camera Stopped.", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        updatePermissionUI();
        if (requestCode == REQ_PICK_VIDEO && resultCode == Activity.RESULT_OK && data != null) {
            selectedVideoUri = data.getData();
            copyUriToVirtualMp4(selectedVideoUri);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (voiceChangerEngine != null) {
            voiceChangerEngine.stop();
        }
    }
}
`
    },
    {
      path: 'app/src/main/java/com/vcam/virtualcamera/service/VirtualCamOverlayService.java',
      description: 'Foreground Floating Window Service with vector notification icon & self-contained drawables',
      content: `package com.vcam.virtualcamera.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.VideoView;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import com.vcam.virtualcamera.MainActivity;
import com.vcam.virtualcamera.R;

public class VirtualCamOverlayService extends Service {

    private WindowManager windowManager;
    private View floatingView;
    private VideoView videoPlayer;
    private WindowManager.LayoutParams params;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(101, createNotification());

        windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        floatingView = inflater.inflate(R.layout.layout_floating_camera, null);

        int layoutType = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        params = new WindowManager.LayoutParams(
                420,
                580,
                layoutType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
        );

        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 80;
        params.y = 150;

        windowManager.addView(floatingView, params);

        videoPlayer = floatingView.findViewById(R.id.floatingVideoView);
        ImageView btnClose = floatingView.findViewById(R.id.btnCloseOverlay);

        btnClose.setOnClickListener(v -> stopSelf());

        floatingView.setOnTouchListener(new View.OnTouchListener() {
            private int initialX, initialY;
            private float initialTouchX, initialTouchY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        params.x = initialX + (int) (event.getRawX() - initialTouchX);
                        params.y = initialY + (int) (event.getRawY() - initialTouchY);
                        windowManager.updateViewLayout(floatingView, params);
                        return true;
                }
                return false;
            }
        });
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.hasExtra("VIDEO_URI")) {
            String uriStr = intent.getStringExtra("VIDEO_URI");
            videoPlayer.setVideoURI(Uri.parse(uriStr));
            videoPlayer.setOnPreparedListener(mp -> {
                mp.setLooping(true);
                videoPlayer.start();
            });
        }
        return START_STICKY;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    "VirtualCamChannel",
                    "Virtual Cam Stream Injection",
                    NotificationManager.IMPORTANCE_LOW
            );
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }

    private Notification createNotification() {
        Intent notificationIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent,
                PendingIntent.FLAG_IMMUTABLE);

        return new NotificationCompat.Builder(this, "VirtualCamChannel")
                .setContentTitle("Virtual Camera Active")
                .setContentText("Streaming virtual video into camera pipe")
                .setSmallIcon(R.drawable.ic_cam_notification)
                .setContentIntent(pendingIntent)
                .build();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (floatingView != null && windowManager != null) {
            windowManager.removeView(floatingView);
        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
`
    },
    {
      path: 'app/src/main/java/com/vcam/virtualcamera/audio/VoiceChangerEngine.java',
      description: 'Real-time pitch modulator reading Mic input and writing modified sample buffer to AudioTrack',
      content: `package com.vcam.virtualcamera.audio;

import android.annotation.SuppressLint;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;

public class VoiceChangerEngine {

    private static final int SAMPLE_RATE = 44100;
    private static final int CHANNEL_IN = AudioFormat.CHANNEL_IN_MONO;
    private static final int CHANNEL_OUT = AudioFormat.CHANNEL_OUT_MONO;
    private static final int ENCODING = AudioFormat.ENCODING_PCM_16BIT;

    private boolean isRunning = false;
    private float pitchFactor = 1.0f;
    private Thread workerThread;

    public void setPitch(float pitch) {
        this.pitchFactor = Math.max(0.4f, Math.min(2.5f, pitch));
    }

    @SuppressLint("MissingPermission")
    public synchronized void start() {
        if (isRunning) return;
        isRunning = true;

        int bufferSize = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_IN, ENCODING);
        if (bufferSize <= 0) bufferSize = 2048;

        AudioRecord recorder = new AudioRecord(
                MediaRecorder.AudioSource.MIC,
                SAMPLE_RATE,
                CHANNEL_IN,
                ENCODING,
                bufferSize * 2
        );

        AudioTrack track = new AudioTrack.Builder()
                .setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build())
                .setAudioFormat(new AudioFormat.Builder()
                        .setEncoding(ENCODING)
                        .setSampleRate((int) (SAMPLE_RATE * pitchFactor))
                        .setChannelMask(CHANNEL_OUT)
                        .build())
                .setBufferSizeInBytes(bufferSize * 2)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build();

        recorder.startRecording();
        track.play();

        workerThread = new Thread(() -> {
            short[] buffer = new short[bufferSize];
            while (isRunning) {
                int read = recorder.read(buffer, 0, buffer.length);
                if (read > 0) {
                    track.write(buffer, 0, read);
                }
            }
            try {
                recorder.stop();
                recorder.release();
                track.stop();
                track.release();
            } catch (Exception ignored) {}
        });

        workerThread.setPriority(Thread.MAX_PRIORITY);
        workerThread.start();
    }

    public synchronized void stop() {
        isRunning = false;
        if (workerThread != null) {
            try {
                workerThread.join(400);
            } catch (InterruptedException ignored) {}
            workerThread = null;
        }
    }
}
`
    },
    {
      path: 'app/src/main/res/layout/activity_main.xml',
      description: 'Clean Layout XML with Live Permission Banner & Dedicated Grant Buttons',
      content: `<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    android:background="#121212"
    android:padding="16dp">

    <TextView
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="VIRTUAL CAMERA (VCAM) ENGINE"
        android:textColor="#00E676"
        android:textSize="18sp"
        android:textStyle="bold" />

    <TextView
        android:id="@+id/txtTargetFilePath"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="VCAM Path: /sdcard/DCIM/Camera1/virtual.mp4"
        android:textColor="#888888"
        android:textSize="11sp"
        android:layout_marginBottom="12dp" />

    <!-- Live Permission Status Banner -->
    <TextView
        android:id="@+id/txtPermissionStatus"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:background="#212121"
        android:padding="10dp"
        android:text="CHECKING PERMISSIONS..."
        android:textColor="#FFC107"
        android:textSize="12sp"
        android:textStyle="bold"
        android:layout_marginBottom="8dp" />

    <Button
        android:id="@+id/btnGrantPermissions"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:backgroundTint="#FF9800"
        android:text="1. GRANT APP PERMISSIONS (CAMERA / STORAGE)"
        android:textColor="#000000"
        android:textStyle="bold"
        android:layout_marginBottom="6dp" />

    <Button
        android:id="@+id/btnGrantOverlay"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:backgroundTint="#FF5722"
        android:text="2. ENABLE OVERLAY (DISPLAY OVER APPS)"
        android:textColor="#FFFFFF"
        android:textStyle="bold"
        android:layout_marginBottom="16dp" />

    <!-- App Selector -->
    <TextView
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Target Video Application:"
        android:textColor="#FFFFFF"
        android:textSize="14sp" />

    <Spinner
        android:id="@+id/spinnerTargetApp"
        android:layout_width="match_parent"
        android:layout_height="48dp"
        android:background="#1E1E1E"
        android:layout_marginBottom="16dp" />

    <!-- Video Selection -->
    <Button
        android:id="@+id/btnSelectVideo"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:backgroundTint="#2979FF"
        android:text="SELECT REPLACEMENT VIDEO (virtual.mp4)"
        android:textColor="#FFFFFF" />

    <!-- Voice Pitch Controls -->
    <TextView
        android:id="@+id/txtPitchValue"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Real-Time Voice Pitch: 1.00x"
        android:textColor="#FFFFFF"
        android:layout_marginTop="16dp" />

    <SeekBar
        android:id="@+id/seekPitch"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:max="100"
        android:progress="33" />

    <!-- Action Buttons -->
    <Button
        android:id="@+id/btnStartService"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_marginTop="20dp"
        android:backgroundTint="#00C853"
        android:text="START VIRTUAL CAMERA INJECTION"
        android:textColor="#FFFFFF" />

    <Button
        android:id="@+id/btnStopService"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_marginTop="8dp"
        android:backgroundTint="#D50000"
        android:text="STOP &amp; RESTORE NORMAL CAMERA"
        android:textColor="#FFFFFF" />

</LinearLayout>
`
    },
    {
      path: 'app/src/main/res/layout/layout_floating_camera.xml',
      description: 'Floating window layout referencing pure vector @drawable/ic_close',
      content: `<?xml version="1.0" encoding="utf-8"?>
<FrameLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="#000000">

    <VideoView
        android:id="@+id/floatingVideoView"
        android:layout_width="match_parent"
        android:layout_height="match_parent" />

    <ImageView
        android:id="@+id/btnCloseOverlay"
        android:layout_width="36dp"
        android:layout_height="36dp"
        android:layout_gravity="top|end"
        android:layout_margin="8dp"
        android:padding="6dp"
        android:src="@drawable/ic_close"
        android:background="#88000000" />
</FrameLayout>
`
    }
  ];
};
