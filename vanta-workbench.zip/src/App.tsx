import React, { useState } from 'react';
import { TargetAppConfig, VideoFilterConfig, VideoSourceType, AudioFilterConfig } from './types';
import { TARGET_APPS } from './projectFiles';
import { VideoCanvasRenderer } from './components/VideoCanvasRenderer';
import { InjectionControls } from './components/InjectionControls';
import { AudioVoiceEngine } from './components/AudioVoiceEngine';
import { ProjectCodeViewer } from './components/ProjectCodeViewer';
import {
  Camera,
  Layers,
  Sparkles,
  Smartphone,
  Cpu,
  ShieldAlert,
  Sliders,
  CheckCircle2,
  Terminal,
  HelpCircle,
  BookOpen,
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'simulator' | 'audio' | 'project_code' | 'guide'>('simulator');
  const [selectedTargetApp, setSelectedTargetApp] = useState<TargetAppConfig>(TARGET_APPS[0]); // WhatsApp
  const [videoSourceType, setVideoSourceType] = useState<VideoSourceType>('sample_elon');
  const [uploadedVideoUrl, setUploadedVideoUrl] = useState<string | null>(null);

  const [videoFilterConfig, setVideoFilterConfig] = useState<VideoFilterConfig>({
    blurBackground: false,
    blurStrength: 5,
    filterEffect: 'none',
    fps: 30,
    faceTrackingOverlay: false,
  });

  const [audioFilterConfig, setAudioFilterConfig] = useState<AudioFilterConfig>({
    enabled: true,
    preset: 'deep_pitch',
    pitchShift: 0.8,
    distortion: 0,
    echo: 0,
  });

  const [isInjecting, setIsInjecting] = useState<boolean>(false);

  const handleUploadVideo = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setUploadedVideoUrl(url);
      setVideoSourceType('custom_upload');
    }
  };

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-200 font-mono flex flex-col selection:bg-emerald-900 selection:text-emerald-100">
      {/* Top Navbar */}
      <header className="border-b border-neutral-800 bg-neutral-900/60 backdrop-blur-md px-6 py-4 flex flex-wrap items-center justify-between gap-4 sticky top-0 z-50">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
            <Camera className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-bold tracking-wider text-white">VIRTUAL CAM STUDIO</span>
              <span className="px-2 py-0.5 rounded-full text-[10px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                Android 16+ Engine
              </span>
            </div>
            <p className="text-[11px] text-neutral-400">Non-Root &amp; No-PC Injection &amp; On-Device IDE Exporter</p>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center bg-neutral-950 border border-neutral-800 p-1 rounded-xl gap-1">
          <button
            type="button"
            onClick={() => setActiveTab('simulator')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'simulator'
                ? 'bg-neutral-800 text-emerald-400 shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Camera className="w-3.5 h-3.5" />
            <span>Live Cam Simulator</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('audio')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'audio'
                ? 'bg-neutral-800 text-emerald-400 shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>Voice Changer</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('project_code')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'project_code'
                ? 'bg-neutral-800 text-emerald-400 shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>Android Code &amp; ZIP</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('guide')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'guide'
                ? 'bg-neutral-800 text-emerald-400 shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>No-PC Build Guide</span>
          </button>
        </div>
      </header>

      {/* Main Workspace Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 space-y-6">
        {/* TAB 1: Live Simulator & Injector Controls */}
        {activeTab === 'simulator' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Left: Video Canvas & Call Preview */}
            <div className="lg:col-span-5 space-y-4">
              <VideoCanvasRenderer
                targetApp={selectedTargetApp}
                videoSourceType={videoSourceType}
                uploadedVideoUrl={uploadedVideoUrl}
                filterConfig={videoFilterConfig}
                isInjecting={isInjecting}
                onStopInjection={() => setIsInjecting(false)}
              />

              {/* Status Indicator */}
              <div className="bg-neutral-900/60 border border-neutral-800 rounded-xl p-4 text-xs space-y-2">
                <div className="flex items-center justify-between text-neutral-400">
                  <span className="flex items-center gap-2">
                    <Cpu className="w-3.5 h-3.5 text-emerald-400" /> Virtual Injection State:
                  </span>
                  <span className={isInjecting ? 'text-emerald-400 font-bold' : 'text-neutral-500'}>
                    {isInjecting ? '● BROADCASTING INJECTED FRAMES' : '○ STANDBY'}
                  </span>
                </div>
                <div className="flex items-center justify-between text-neutral-400">
                  <span>Injected Subject:</span>
                  <span className="text-neutral-200 font-semibold">
                    {videoSourceType === 'sample_elon' ? 'Elon Musk Synthetic Stream' : 'Custom User Video'}
                  </span>
                </div>
                <div className="flex items-center justify-between text-neutral-400">
                  <span>Voice DSP Pitch:</span>
                  <span className="text-cyan-400 font-semibold">{audioFilterConfig.pitchShift.toFixed(2)}x</span>
                </div>
              </div>
            </div>

            {/* Right: Controls & Parameters */}
            <div className="lg:col-span-7 space-y-4">
              <InjectionControls
                targetApp={selectedTargetApp}
                onSelectTargetApp={setSelectedTargetApp}
                videoSourceType={videoSourceType}
                onSelectVideoSource={setVideoSourceType}
                uploadedVideoUrl={uploadedVideoUrl}
                onUploadVideo={handleUploadVideo}
                videoFilterConfig={videoFilterConfig}
                onChangeVideoFilter={setVideoFilterConfig}
                isInjecting={isInjecting}
                onStartInjection={() => setIsInjecting(true)}
                onStopInjection={() => setIsInjecting(false)}
              />

              {/* Real-time Voice Quick Module */}
              <AudioVoiceEngine
                filterConfig={audioFilterConfig}
                onChangeFilter={setAudioFilterConfig}
                isStreaming={isInjecting}
              />
            </div>
          </div>
        )}

        {/* TAB 2: Audio & Voice Engine */}
        {activeTab === 'audio' && (
          <div className="max-w-3xl mx-auto space-y-6">
            <AudioVoiceEngine
              filterConfig={audioFilterConfig}
              onChangeFilter={setAudioFilterConfig}
              isStreaming={isInjecting}
            />

            <div className="bg-neutral-900/40 border border-neutral-800 rounded-xl p-5 text-xs text-neutral-400 space-y-3">
              <div className="text-emerald-400 font-bold text-sm">🎙️ Audio Injection Pipeline Architecture</div>
              <p className="leading-relaxed">
                Android standard audio hal routes microphone buffers through the <code>AudioRecord</code> buffer
                pipeline. The <code>VoiceChangerEngine.java</code> class in our export uses low-latency PCM 16-bit mono
                buffers and dynamically recalculates sample rate and frequency response before writing back to{' '}
                <code>AudioTrack</code> in real time.
              </p>
              <div className="grid grid-cols-2 gap-3 pt-2">
                <div className="p-3 bg-neutral-950 rounded-lg border border-neutral-800">
                  <div className="font-bold text-neutral-200">Sample Rate</div>
                  <div className="text-emerald-400">44,100 Hz (PCM 16-bit)</div>
                </div>
                <div className="p-3 bg-neutral-950 rounded-lg border border-neutral-800">
                  <div className="font-bold text-neutral-200">Processing Latency</div>
                  <div className="text-cyan-400">&lt; 18ms (Near Zero Lag)</div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: Android IDE Project Files & ZIP Export */}
        {activeTab === 'project_code' && (
          <div className="space-y-4">
            <ProjectCodeViewer targetPackage={selectedTargetApp.packageName} />
          </div>
        )}

        {/* TAB 4: No-PC Build Guide (AndroidIDE / AIDE) */}
        {activeTab === 'guide' && (
          <div className="bg-neutral-900/60 border border-neutral-800 rounded-xl p-6 text-xs font-mono space-y-6 max-w-4xl mx-auto">
            <div className="border-b border-neutral-800 pb-4">
              <h2 className="text-base font-bold text-emerald-400 flex items-center gap-2">
                <Smartphone className="w-5 h-5" />
                <span>How to Build .APK on Android Without PC / Without ADB</span>
              </h2>
              <p className="text-neutral-400 text-xs mt-1">
                Step-by-step instructions to compile this exact project on Android 10 to 16+ using on-device IDEs.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Option 1: GitHub Actions APK Compiler */}
              <div className="bg-neutral-950 border border-neutral-800 rounded-xl p-5 space-y-3">
                <div className="text-purple-400 font-bold text-sm">Option A: GitHub Actions (Auto APK Build)</div>
                <ol className="list-decimal list-inside space-y-2 text-neutral-300">
                  <li>Upload/Push the exported project directly to your GitHub repository.</li>
                  <li>
                    Ensure <code>gradlew</code> is uploaded in the <strong>root repository folder</strong> (not inside a subfolder).
                  </li>
                  <li>GitHub will automatically run the workflow in <code>.github/workflows/build-apk.yml</code>.</li>
                  <li>Once green, go to <strong>Actions &gt; build &gt; Artifacts</strong>.</li>
                  <li>Download <strong>VirtualCam-app-debug.apk</strong> directly to your phone!</li>
                </ol>
              </div>

              {/* Option 2: AndroidIDE */}
              <div className="bg-neutral-950 border border-neutral-800 rounded-xl p-5 space-y-3">
                <div className="text-cyan-400 font-bold text-sm">Option B: AndroidIDE (On-Phone App)</div>
                <ol className="list-decimal list-inside space-y-2 text-neutral-300">
                  <li>
                    Download <strong>AndroidIDE</strong> from F-Droid or GitHub.
                  </li>
                  <li>
                    Click the <strong>"Export Complete Project (.ZIP)"</strong> button in the project tab.
                  </li>
                  <li>Extract the downloaded zip in your phone's storage.</li>
                  <li>Open AndroidIDE &gt; Tap <strong>Open Project</strong> &gt; Select folder.</li>
                  <li>
                    Tap the <strong>▶ Run</strong> button or execute <code>./gradlew assembleDebug</code> in its
                    built-in terminal.
                  </li>
                </ol>
              </div>

              {/* Option 3: AIDE */}
              <div className="bg-neutral-950 border border-neutral-800 rounded-xl p-5 space-y-3">
                <div className="text-amber-400 font-bold text-sm">Option C: AIDE (Quick Java IDE)</div>
                <ol className="list-decimal list-inside space-y-2 text-neutral-300">
                  <li>Install <strong>AIDE</strong> directly from the Play Store / APKPure.</li>
                  <li>Download &amp; extract our project zip into your internal storage.</li>
                  <li>In AIDE, navigate to the folder containing <code>AndroidManifest.xml</code>.</li>
                  <li>Tap <strong>Menu &gt; Run</strong> to compile into APK.</li>
                </ol>
              </div>
            </div>

            {/* Android 16+ Non-Root Note */}
            <div className="bg-emerald-950/30 border border-emerald-500/30 rounded-xl p-4 text-emerald-300 space-y-1.5">
              <div className="font-bold flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Non-Root &amp; Floating Window Injection Security Model</span>
              </div>
              <p className="text-[11px] text-emerald-200/80 leading-relaxed">
                Because modern Android (Android 14, 15, and 16+) blocks third-party background process memory hooking
                without root, this project uses the <strong>Foreground Floating Window + Virtual Audio Engine</strong>{' '}
                architecture. This allows the custom face video (e.g. Elon Musk loop) to play continuously in a locked,
                customizable PIP/Camera layout right over active calls (WhatsApp, Google Meet, etc.) with real-time
                voice modulation without requiring Root, ADB, or PC.
              </p>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-neutral-900 px-6 py-4 text-center text-xs text-neutral-600">
        VirtualCam Studio · Non-Root Android 16+ Virtual Camera &amp; Voice Injector Engine
      </footer>
    </div>
  );
}
