export interface AndroidProjectFile {
  path: string;
  content: string;
  description: string;
}

export type TargetAppId = 'whatsapp' | 'telegram' | 'instagram' | 'meet' | 'zoom' | 'custom';

export interface TargetAppConfig {
  id: TargetAppId;
  name: string;
  packageName: string;
  icon: string;
  themeColor: string;
  cameraCallType: 'Camera2' | 'CameraX' | 'WebRTC';
}

export type VideoSourceType = 'sample_elon' | 'sample_tech' | 'sample_avatar' | 'custom_upload' | 'live_camera';

export interface AudioFilterConfig {
  enabled: boolean;
  preset: 'robot' | 'deep_pitch' | 'chipmunk' | 'alien' | 'radio' | 'normal';
  pitchShift: number; // 0.5 to 2.0
  distortion: number; // 0 to 1
  echo: number; // 0 to 1
}

export interface VideoFilterConfig {
  blurBackground: boolean;
  blurStrength: number;
  filterEffect: 'none' | 'cyberpunk' | 'vintage' | 'matrix' | 'hdr' | 'nightvision' | 'glitch';
  fps: number;
  faceTrackingOverlay: boolean;
}
