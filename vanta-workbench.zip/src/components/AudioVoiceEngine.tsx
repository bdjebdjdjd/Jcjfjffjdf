import React, { useEffect, useRef, useState } from 'react';
import { Play, Square, Mic, MicOff, Volume2, Sparkles, Sliders } from 'lucide-react';
import { AudioFilterConfig } from '../types';

interface AudioVoiceEngineProps {
  filterConfig: AudioFilterConfig;
  onChangeFilter: (config: AudioFilterConfig) => void;
  isStreaming: boolean;
}

export const AudioVoiceEngine: React.FC<AudioVoiceEngineProps> = ({
  filterConfig,
  onChangeFilter,
  isStreaming,
}) => {
  const [isMicActive, setIsMicActive] = useState<boolean>(false);
  const [audioLevel, setAudioLevel] = useState<number>(0);
  const audioContextRef = useRef<AudioContext | null>(null);
  const micStreamRef = useRef<MediaStream | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const biquadFilterRef = useRef<BiquadFilterNode | null>(null);
  const waveShaperRef = useRef<WaveShaperNode | null>(null);
  const animFrameRef = useRef<number | null>(null);

  const startMic = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      micStreamRef.current = stream;

      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const ctx = new AudioCtx();
      audioContextRef.current = ctx;

      const source = ctx.createMediaStreamSource(stream);
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 64;
      analyserRef.current = analyser;

      const biquad = ctx.createBiquadFilter();
      biquadFilterRef.current = biquad;

      const shaper = ctx.createWaveShaper();
      waveShaperRef.current = shaper;

      // Connect pipeline
      source.connect(biquad);
      biquad.connect(shaper);
      shaper.connect(analyser);
      analyser.connect(ctx.destination);

      setIsMicActive(true);
      monitorAudioLevel();
    } catch (err) {
      console.warn('Microphone permission / access denied or not available:', err);
    }
  };

  const stopMic = () => {
    if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    if (micStreamRef.current) {
      micStreamRef.current.getTracks().forEach((t) => t.stop());
      micStreamRef.current = null;
    }
    if (audioContextRef.current) {
      audioContextRef.current.close();
      audioContextRef.current = null;
    }
    setIsMicActive(false);
    setAudioLevel(0);
  };

  const monitorAudioLevel = () => {
    if (!analyserRef.current) return;
    const dataArray = new Uint8Array(analyserRef.current.frequencyBinCount);
    const update = () => {
      if (!analyserRef.current) return;
      analyserRef.current.getByteFrequencyData(dataArray);
      let sum = 0;
      for (let i = 0; i < dataArray.length; i++) {
        sum += dataArray[i];
      }
      const avg = sum / dataArray.length;
      setAudioLevel(Math.min(100, Math.round((avg / 255) * 100 * 1.8)));
      animFrameRef.current = requestAnimationFrame(update);
    };
    update();
  };

  // Sync Audio Presets & DSP Filters
  useEffect(() => {
    if (!biquadFilterRef.current || !audioContextRef.current) return;
    const biquad = biquadFilterRef.current;

    switch (filterConfig.preset) {
      case 'deep_pitch':
        biquad.type = 'lowpass';
        biquad.frequency.setValueAtTime(450, audioContextRef.current.currentTime);
        break;
      case 'chipmunk':
        biquad.type = 'highpass';
        biquad.frequency.setValueAtTime(1400, audioContextRef.current.currentTime);
        break;
      case 'robot':
        biquad.type = 'bandpass';
        biquad.frequency.setValueAtTime(900, audioContextRef.current.currentTime);
        biquad.Q.setValueAtTime(8, audioContextRef.current.currentTime);
        break;
      case 'radio':
        biquad.type = 'bandpass';
        biquad.frequency.setValueAtTime(1200, audioContextRef.current.currentTime);
        biquad.Q.setValueAtTime(3, audioContextRef.current.currentTime);
        break;
      case 'alien':
        biquad.type = 'peaking';
        biquad.frequency.setValueAtTime(600, audioContextRef.current.currentTime);
        biquad.gain.setValueAtTime(15, audioContextRef.current.currentTime);
        break;
      default:
        biquad.type = 'allpass';
        break;
    }
  }, [filterConfig.preset]);

  return (
    <div className="bg-neutral-900/60 border border-neutral-800 rounded-xl p-4 text-xs font-mono space-y-4">
      <div className="flex items-center justify-between border-b border-neutral-800 pb-2">
        <div className="flex items-center gap-2 text-emerald-400 font-semibold uppercase tracking-wider">
          <Volume2 className="w-4 h-4" />
          <span>Real-Time Voice Changer Engine</span>
        </div>
        <div className="flex items-center gap-2">
          {isMicActive ? (
            <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[10px] flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" /> LIVE MODULATOR
            </span>
          ) : (
            <span className="text-[10px] text-neutral-500">STANDBY</span>
          )}
        </div>
      </div>

      {/* Mic Toggle & Audio Level Visualizer */}
      <div className="flex items-center gap-3">
        <button
          type="button"
          onClick={isMicActive ? stopMic : startMic}
          className={`px-3 py-2 rounded-lg flex items-center gap-2 transition-colors font-medium ${
            isMicActive
              ? 'bg-rose-950/80 hover:bg-rose-900 border border-rose-700 text-rose-200'
              : 'bg-emerald-950/80 hover:bg-emerald-900 border border-emerald-700 text-emerald-200'
          }`}
        >
          {isMicActive ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
          <span>{isMicActive ? 'Mute Mic' : 'Test Real-Time Mic'}</span>
        </button>

        <div className="flex-1 bg-neutral-950 border border-neutral-800 rounded-lg p-2 flex items-center gap-2">
          <span className="text-[10px] text-neutral-500">INPUT:</span>
          <div className="flex-1 bg-neutral-900 rounded-full h-2 overflow-hidden">
            <div
              className={`h-full transition-all duration-75 ${
                audioLevel > 70 ? 'bg-rose-500' : audioLevel > 30 ? 'bg-amber-400' : 'bg-emerald-500'
              }`}
              style={{ width: `${isMicActive ? audioLevel : 0}%` }}
            />
          </div>
          <span className="text-[10px] text-neutral-400 w-8 text-right">{isMicActive ? `${audioLevel}%` : '0%'}</span>
        </div>
      </div>

      {/* Preset Selector */}
      <div className="space-y-1.5">
        <label className="text-[11px] text-neutral-400 flex items-center gap-1.5">
          <Sparkles className="w-3 h-3 text-amber-400" /> Voice Presets
        </label>
        <div className="grid grid-cols-3 gap-2">
          {[
            { id: 'normal', label: 'Normal / Passthrough', icon: '🎙️' },
            { id: 'deep_pitch', label: 'Deep Elon / Male', icon: '🕶️' },
            { id: 'chipmunk', label: 'High / Chipmunk', icon: '🐿️' },
            { id: 'robot', label: 'Cyber Robot', icon: '🤖' },
            { id: 'alien', label: 'Alien / Sci-Fi', icon: '👽' },
            { id: 'radio', label: 'Walkie-Talkie', icon: '📻' },
          ].map((preset) => (
            <button
              key={preset.id}
              type="button"
              onClick={() => onChangeFilter({ ...filterConfig, preset: preset.id as AudioFilterConfig['preset'] })}
              className={`p-2 rounded-lg border text-left transition-all ${
                filterConfig.preset === preset.id
                  ? 'bg-emerald-950/60 border-emerald-500 text-emerald-200'
                  : 'bg-neutral-950/40 border-neutral-800 text-neutral-400 hover:border-neutral-700 hover:text-neutral-200'
              }`}
            >
              <div className="text-sm">{preset.icon}</div>
              <div className="text-[10px] font-semibold mt-0.5 truncate">{preset.label}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Pitch Slider */}
      <div className="space-y-1 pt-1">
        <div className="flex justify-between text-[11px]">
          <span className="text-neutral-400 flex items-center gap-1">
            <Sliders className="w-3 h-3 text-cyan-400" /> Pitch Multiplier
          </span>
          <span className="text-cyan-400 font-bold">{filterConfig.pitchShift.toFixed(2)}x</span>
        </div>
        <input
          type="range"
          min="0.5"
          max="2.0"
          step="0.05"
          value={filterConfig.pitchShift}
          onChange={(e) => onChangeFilter({ ...filterConfig, pitchShift: parseFloat(e.target.value) })}
          className="w-full accent-cyan-400 bg-neutral-950 h-1.5 rounded cursor-pointer"
        />
        <div className="flex justify-between text-[9px] text-neutral-600">
          <span>0.50x (Deep Bass)</span>
          <span>1.00x (Standard)</span>
          <span>2.00x (Ultra High)</span>
        </div>
      </div>
    </div>
  );
};
