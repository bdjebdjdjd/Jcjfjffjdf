import React, { useRef, useEffect } from 'react';
import { TargetAppConfig, VideoFilterConfig, VideoSourceType } from '../types';
import { Video, ShieldCheck, PhoneOff, Sliders, Eye, Sparkles } from 'lucide-react';

interface VideoCanvasRendererProps {
  targetApp: TargetAppConfig;
  videoSourceType: VideoSourceType;
  uploadedVideoUrl: string | null;
  filterConfig: VideoFilterConfig;
  isInjecting: boolean;
  onStopInjection: () => void;
}

export const VideoCanvasRenderer: React.FC<VideoCanvasRendererProps> = ({
  targetApp,
  videoSourceType,
  uploadedVideoUrl,
  filterConfig,
  isInjecting,
  onStopInjection,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const hiddenVideoRef = useRef<HTMLVideoElement | null>(null);
  const animationFrameRef = useRef<number | null>(null);

  // Sample animated synthetic faces if no custom video uploaded
  const drawSyntheticFace = (ctx: CanvasRenderingContext2D, width: number, height: number, time: number) => {
    // Cyber / Synthesized Elon face wireframe
    ctx.fillStyle = '#0a0a0c';
    ctx.fillRect(0, 0, width, height);

    // Background matrix/grid or glow
    ctx.strokeStyle = '#1e293b';
    ctx.lineWidth = 1;
    for (let x = 0; x < width; x += 30) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();
    }
    for (let y = 0; y < height; y += 30) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }

    const cx = width / 2;
    const cy = height / 2 - 20;

    // Face Oval / Avatar representation
    const headSway = Math.sin(time * 0.003) * 6;
    const blink = Math.sin(time * 0.005) > 0.94;

    // Hair / Head silhouette
    ctx.fillStyle = '#262626';
    ctx.beginPath();
    ctx.ellipse(cx + headSway, cy - 20, 80, 100, 0, 0, Math.PI * 2);
    ctx.fill();

    // Face Skin / Tone
    ctx.fillStyle = '#e2b391';
    ctx.beginPath();
    ctx.ellipse(cx + headSway, cy + 10, 65, 85, 0, 0, Math.PI * 2);
    ctx.fill();

    // Eyes
    ctx.fillStyle = '#1c1917';
    if (!blink) {
      ctx.beginPath();
      ctx.ellipse(cx - 25 + headSway, cy, 8, 5, 0, 0, Math.PI * 2);
      ctx.ellipse(cx + 25 + headSway, cy, 8, 5, 0, 0, Math.PI * 2);
      ctx.fill();
    } else {
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(cx - 33 + headSway, cy);
      ctx.lineTo(cx - 17 + headSway, cy);
      ctx.moveTo(cx + 17 + headSway, cy);
      ctx.lineTo(cx + 33 + headSway, cy);
      ctx.stroke();
    }

    // Nose & Mouth (Talking animation)
    const mouthOpen = Math.abs(Math.sin(time * 0.008)) * 12;
    ctx.fillStyle = '#991b1b';
    ctx.beginPath();
    ctx.ellipse(cx + headSway, cy + 50, 16, 4 + mouthOpen, 0, 0, Math.PI * 2);
    ctx.fill();

    // Injected Identity Tag
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 13px monospace';
    ctx.textAlign = 'center';
    ctx.fillText('INJECTED STREAM: ELON MUSK (SYNTH VIRTUAL CAM)', cx, height - 60);

    ctx.fillStyle = '#10b981';
    ctx.font = '11px monospace';
    ctx.fillText('STREAM STATUS: ACTIVE (30 FPS LOCKED)', cx, height - 40);
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let startTime = Date.now();

    const render = () => {
      const now = Date.now();
      const elapsed = now - startTime;
      const width = canvas.width;
      const height = canvas.height;

      // Check if real video is playing
      if (hiddenVideoRef.current && uploadedVideoUrl && !hiddenVideoRef.current.paused) {
        ctx.drawImage(hiddenVideoRef.current, 0, 0, width, height);
      } else {
        drawSyntheticFace(ctx, width, height, elapsed);
      }

      // Apply Filters
      if (filterConfig.blurBackground) {
        // Blur simulated overlay
        ctx.fillStyle = 'rgba(0, 0, 0, 0.2)';
        ctx.fillRect(0, 0, width, height);
      }

      // Custom Color Grading Filters
      if (filterConfig.filterEffect === 'cyberpunk') {
        ctx.fillStyle = 'rgba(236, 72, 153, 0.15)';
        ctx.fillRect(0, 0, width, height);
      } else if (filterConfig.filterEffect === 'matrix') {
        ctx.fillStyle = 'rgba(16, 185, 129, 0.18)';
        ctx.fillRect(0, 0, width, height);
      } else if (filterConfig.filterEffect === 'nightvision') {
        ctx.fillStyle = 'rgba(34, 197, 94, 0.22)';
        ctx.fillRect(0, 0, width, height);
      } else if (filterConfig.filterEffect === 'vintage') {
        ctx.fillStyle = 'rgba(217, 119, 6, 0.15)';
        ctx.fillRect(0, 0, width, height);
      } else if (filterConfig.filterEffect === 'glitch') {
        if (Math.random() > 0.85) {
          const sliceY = Math.random() * height;
          const sliceHeight = 20;
          ctx.fillStyle = '#06b6d4';
          ctx.fillRect(0, sliceY, width, sliceHeight);
        }
      }

      // Real-Time Face Tracking Box overlay if enabled
      if (filterConfig.faceTrackingOverlay) {
        const cx = width / 2;
        const cy = height / 2 - 20;
        ctx.strokeStyle = '#00e676';
        ctx.lineWidth = 2;
        ctx.strokeRect(cx - 75, cy - 90, 150, 190);

        ctx.fillStyle = '#00e676';
        ctx.font = '10px monospace';
        ctx.fillText('TARGET MESH [LOCK 99.8%]', cx - 70, cy - 95);
      }

      animationFrameRef.current = requestAnimationFrame(render);
    };

    render();

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [filterConfig, uploadedVideoUrl]);

  return (
    <div className="relative border border-neutral-800 bg-neutral-950 rounded-xl overflow-hidden flex flex-col items-center">
      {/* Hidden Video element for uploaded videos */}
      {uploadedVideoUrl && (
        <video
          ref={hiddenVideoRef}
          src={uploadedVideoUrl}
          loop
          autoPlay
          muted
          playsInline
          className="hidden"
        />
      )}

      {/* Target App Bar (Simulating WhatsApp / Telegram call header) */}
      <div
        className="w-full px-4 py-2.5 flex items-center justify-between text-xs font-mono text-white"
        style={{ backgroundColor: targetApp.themeColor + '22', borderBottom: `1px solid ${targetApp.themeColor}55` }}
      >
        <div className="flex items-center gap-2">
          <div
            className="w-2.5 h-2.5 rounded-full animate-ping"
            style={{ backgroundColor: targetApp.themeColor }}
          />
          <span className="font-bold tracking-wider">{targetApp.name.toUpperCase()} VIDEO CALL</span>
        </div>
        <div className="flex items-center gap-2 text-[10px] text-neutral-400">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>INJECTOR HOOK: {isInjecting ? 'LOCKED & TRANSMITTING' : 'IDLE'}</span>
        </div>
      </div>

      {/* Main Canvas Screen */}
      <div className="relative w-full max-w-[480px] aspect-[3/4] bg-black flex items-center justify-center">
        <canvas
          ref={canvasRef}
          width={480}
          height={640}
          className="w-full h-full object-cover"
        />

        {/* Live Call Floating HUD */}
        <div className="absolute top-4 left-4 right-4 flex justify-between items-start pointer-events-none">
          <div className="bg-black/70 backdrop-blur-md border border-neutral-700/80 rounded-lg px-2.5 py-1.5 text-[11px] font-mono text-emerald-400 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span>V-CAM: 1080p @ 30FPS</span>
          </div>

          <div className="bg-black/70 backdrop-blur-md border border-neutral-700/80 rounded-lg px-2.5 py-1.5 text-[11px] font-mono text-cyan-400">
            {targetApp.packageName}
          </div>
        </div>

        {/* Stop Injection Overlay Button */}
        {isInjecting && (
          <div className="absolute bottom-4 left-0 right-0 flex justify-center px-4">
            <button
              type="button"
              onClick={onStopInjection}
              className="bg-rose-600 hover:bg-rose-500 active:bg-rose-700 text-white font-mono font-bold text-xs px-6 py-3 rounded-xl shadow-lg shadow-rose-900/50 flex items-center gap-2 transition-all transform hover:scale-105"
            >
              <PhoneOff className="w-4 h-4" />
              <span>STOP INJECTION & RESTORE NORMAL CAMERA</span>
            </button>
          </div>
        )}
      </div>

      {/* Status Bar */}
      <div className="w-full p-2.5 bg-neutral-900/80 border-t border-neutral-800 text-[10px] font-mono text-neutral-400 flex justify-between items-center">
        <span>FRAME BUFFER: VIRTUAL YUV420 &gt; {targetApp.cameraCallType}</span>
        <span className="text-emerald-400 font-semibold">NON-ROOT PIPELINE ACTIVE</span>
      </div>
    </div>
  );
};
